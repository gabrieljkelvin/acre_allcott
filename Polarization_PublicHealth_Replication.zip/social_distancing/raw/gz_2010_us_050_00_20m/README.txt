
Data downloaded from https://www.census.gov/geo/maps-data/data/cbf/cbf_counties.html on July 24, 2018 by Levi Boxell.

Selected gz_2010_us_050_00_20m.zip

