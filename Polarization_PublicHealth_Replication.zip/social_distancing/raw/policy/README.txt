--------------------------------------------------------------------------------
OVERVIEW
--------------------------------------------------------------------------------
Data on state and county shelter-in-place policy start dates

--------------------------------------------------------------------------------
SOURCE
--------------------------------------------------------------------------------
Received from Billy Ferguson, "Economic and Health Impacts of Social Distancing Policies during the Coronavirus Pandemic", Allcott, Boxell, Conway, Ferguson & Goldman (2020)

--------------------------------------------------------------------------------
WHEN/WHERE OBTAINED & ORIGINAL FORM OF FILES
--------------------------------------------------------------------------------
Received on May 9th, 2020.