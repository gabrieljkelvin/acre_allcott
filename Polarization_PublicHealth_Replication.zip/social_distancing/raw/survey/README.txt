--------------------------------------------------------------------------------
OVERVIEW
--------------------------------------------------------------------------------
cloudresearch_4-7-20_raw: Data for survey analysis.
cloudresearch_participants: Participant list from CloudResearch to match IDs.

--------------------------------------------------------------------------------
SOURCE
--------------------------------------------------------------------------------
Raw survey data: Data collected from April 4-7, 2020 on Qualtrics.
Participant list: Received from Blake Wardrop at CloudResearch via email.

--------------------------------------------------------------------------------
WHEN/WHERE OBTAINED & ORIGINAL FORM OF FILES
--------------------------------------------------------------------------------
Both received on April 7, 2020.
