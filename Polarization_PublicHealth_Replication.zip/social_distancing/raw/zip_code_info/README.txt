--------------------------------------------------------------------------------
OVERVIEW
--------------------------------------------------------------------------------
Data on ZIP-code-level characteristics, used in survey analysis

--------------------------------------------------------------------------------
SOURCE
--------------------------------------------------------------------------------
2010 US Census Zip Code Tabulation Area (ZCTA) Relationship Files:
https://www2.census.gov/geo/docs/maps-data/data/rel/zcta_county_rel_10.txt#

--------------------------------------------------------------------------------
WHEN/WHERE OBTAINED & ORIGINAL FORM OF FILES
--------------------------------------------------------------------------------
Data downloaded by Michael Thaler on March 29, 2020.
